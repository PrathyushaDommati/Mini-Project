package reservation;

import java.util.Scanner;

public class ReserveMain {

	public static void main(String[] args) {
		RerserveOprtnImp re=new RerserveOprtnImp();
		System.out.println("Welcome to Airline Reservation ");
		while (true) {
			System.out.println("1.Book Ticket\n 2.Cancel Ticket\n 3.View Chart\n 4.Exit");
			System.out.println("Enter your choice ");
			Scanner in=new Scanner(System.in);
			int ch=in.nextInt();
	
		 if(ch==1)
			{
				re.bookTicket();
			}
			else if(ch==2)
			{
				
				re.CancelTicket();
			}
			else if (ch==3)
			{
				re.viewTickets();
			}
			else if (ch==4)
			{
				System.out.println("Thank you for using Airline reservation System");
				System.exit(0);
			}
			else
			{
				System.out.println("Your choice is invalid...Try again");
			}
		}
	}

}

