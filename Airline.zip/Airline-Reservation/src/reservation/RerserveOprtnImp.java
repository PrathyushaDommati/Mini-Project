package reservation;
import java.util.*;
import java.util.Scanner;

public class RerserveOprtnImp implements Reserveop {

	HashMap<Integer,String> reservations=new HashMap<>();
	int totalseats=5;
	Scanner in=new Scanner(System.in);

@Override
public void bookTicket() {
	if(reservations.size()<totalseats)
	{
		System.out.println("Enter your name");
		String PassengerName=in.next();
		System.out.println("Enter the seat number from 1-"+ totalseats);
		int Seatnum=in.nextInt();
		if (reservations.containsKey(Seatnum) || Seatnum>totalseats) {
			System.out.println(" Please choose available or Valid Seat number");
		}
		else {
		System.out.println("Reservation successfull "+Seatnum+" "+PassengerName);
		reservations.put(Seatnum,"Occupied");
		viewTickets();
		}
	}else {
		System.out.println("Sorry... All Seats are reserved");
	}
	
	
}
@Override
public void CancelTicket() {
	System.out.println("Enter your seat number");
	 int Seatnum=in.nextInt();
	if (reservations.containsKey(Seatnum)) {
		System.out.println(Seatnum+" Cancelled");
		reservations.remove(Seatnum);
	}else {
		System.out.println("This Seatnumber is not yet reserved");
	}
	
	}

@Override
public void viewTickets() {
	if (reservations.isEmpty()) {
		System.out.println("All Seats are Available");
	}else {
	for(Map.Entry<Integer,String>m:reservations.entrySet())
	{
		System.out.println(m.getKey()+" "+m.getValue());
	}	
	}
}
}


